package com.sist.main;

import javax.swing.JPanel;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
public class EmpListPane extends JPanel{
	JLabel la;
	JTable table;
	DefaultTableModel model;
	JLabel la1,la2;
	JComboBox box;
	JTextField tf;
	JButton b1,b2,b3,b4;
	public EmpListPane(){
		setLayout(new BorderLayout());
		la=new JLabel("������",JLabel.CENTER);
		la.setFont(new Font("���� ����", Font.BOLD, 30));
		
		String[] col={"���","�̸�","����","�Ի���","�μ���ȣ"};
		String[][] row=new String[0][2];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		la1=new JLabel("Search");
		box=new JComboBox();
		box.addItem("�̸�");
		box.addItem("�Ի���");
		box.addItem("�μ�");
		
		tf=new JTextField(10);
		b1=new JButton("�˻�");
		b2=new JButton("���");
		b3=new JButton("����");
		b4=new JButton("����");
		
		la2=new JLabel("0 page / 0 pages");
		
		JPanel p1=new JPanel();
		p1.add(la1);p1.add(box);p1.add(tf);
		p1.add(b1);p1.add(b2);
		
		JPanel p2=new JPanel();
		p2.add(b3);p2.add(b4);
		p2.add(la2);
		
		JPanel p3=new JPanel();
		p3.setLayout(new GridLayout(1,2,35,25));
		p3.add(p1);
		p3.add(p2);
		
		add("North", la);
		add("Center",js);
		add("South",p3);
		
	}
}

















