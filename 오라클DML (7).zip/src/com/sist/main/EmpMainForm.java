package com.sist.main;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import com.sist.dao.EmpDAO;
import com.sist.dao.EmpVO;

public class EmpMainForm extends JFrame
				implements ActionListener,MouseListener{

	EmpDAO dao=new EmpDAO();
	EmpListPane ep=new EmpListPane();
	EmpDetailPanel ed=new EmpDetailPanel();
	EmpInsert ei=new EmpInsert();
	
	CardLayout card=new CardLayout();
	
	int curpage=1;
	int totalPage=0;
	JMenuItem regItem,exitItem;
	int eno=0;
	
	public EmpMainForm() {
		JMenuBar bar=new JMenuBar();
		JMenu menu=new JMenu("����");
		regItem=new JMenuItem("���");
		exitItem=new JMenuItem("����");
		
		menu.add(regItem);
		menu.add(exitItem);
		
		bar.add(menu);
		setJMenuBar(bar);
		
		setLayout(card);
		
		add("EP",ep);
		add("ED",ed);
		
		setSize(800,600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	
		getEmpData();
		
		ep.tf.addActionListener(this);
		ep.b1.addActionListener(this);//ã��
		ep.b2.addActionListener(this);//���
		ep.b3.addActionListener(this);//����
		ep.b4.addActionListener(this);//����
		regItem.addActionListener(this); //���
		exitItem.addActionListener(this);//����
		ep.table.addMouseListener(this); //������ ���γ���
		
		ei.b1.addActionListener(this);
		ei.b2.addActionListener(this);
		
		ed.b1.addActionListener(this);
		ed.b2.addActionListener(this);
		ed.b3.addActionListener(this);
		
		
	}
	
	public static void main(String[] args){
		new EmpMainForm();
	}
	
	public void getEmpData(){
		ArrayList<EmpVO> list=
				dao.empListData(curpage);
		for(int i=ep.model.getRowCount()-1;i>=0;i--){
			ep.model.removeRow(i);
		}
		
		for(EmpVO vo:list){
			String[] data={
				String.valueOf(vo.getEmpno()),
				vo.getEname(),
				vo.getJob(),
				vo.getHiredate().toString(),
				String.valueOf(vo.getDeptno())
				
			};
			ep.model.addRow(data);
		}
		totalPage=dao.empTotalPage();
		ep.la2.setText(curpage+" page /"+totalPage+" pages");
		
	}
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==ep.table){
			if(e.getClickCount()==2){
				int row=ep.table.getSelectedRow();
				String empno=ep.model.getValueAt(row, 0).toString();
				EmpVO vo=
					dao.empDetailData(Integer.parseInt(empno));
				String[] data={
					String.valueOf(vo.getEmpno()),
					vo.getEname(),
					vo.getJob(),
					String.valueOf(vo.getMgr()),
					vo.getHiredate().toString(),
					String.valueOf(vo.getSal()),
					String.valueOf(vo.getComm()),
					vo.getDvo().getDname(),
					vo.getDvo().getLoc(),
					String.valueOf(vo.getSvo().getGrade())
				};
				//EmpDetailPanel �� �׸� ä������.
				for(int i=0;i<10;i++){
					ed.tf[i].setText(data[i]);
				}
				card.show(getContentPane(), "ED");
			}
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==ep.b3){
			if(curpage>1){
				curpage--;
				getEmpData();
			}
		}else if(e.getSource()==ep.b4){
			if(curpage<totalPage){
				curpage++;
				getEmpData();
			}
		}else if(e.getSource()==ed.b3){		//�󼼺���=>���
			card.show(getContentPane(), "EP");  //EmpListPane
		}else if(e.getSource()==regItem){
			ei.b1.setText("���");
			ei.tf1.setText("");
			ei.tf2.setText("");
			ei.tf3.setText("");
			ei.box1.setSelectedIndex(0);
			ei.box2.setSelectedIndex(0);
			ei.box3.setSelectedIndex(0);
			ei.setVisible(true);
		}else if(e.getSource()==exitItem){
			System.exit(0);
		}else if(e.getSource()==ei.b1){
			String ename=ei.tf1.getText();
			if(ename.length()<1){
				JOptionPane.
				showMessageDialog(this, "�̸��� �Է��ϼ���.");
				ei.tf1.requestFocus();
				return;
			}
			String job=ei.box1.getSelectedItem().toString();
			String mgr=ei.box2.getSelectedItem().toString();
			String sal=ei.tf2.getText();
			if(sal.length()<1){
				JOptionPane.
				showMessageDialog(this, "�޿��� �Է��ϼ���.");
				ei.tf2.requestFocus();
				return;
			}		
			String comm=ei.tf3.getText();
			if(comm.length()<1){
				JOptionPane.
				showMessageDialog(this, "�������� �Է��ϼ���.");
				ei.tf3.requestFocus();
				return;
			}			
			String deptno=ei.box3.getSelectedItem().toString();
			
			EmpVO vo=new EmpVO();
			vo.setEname(ename);
			vo.setJob(job);
			vo.setMgr(Integer.parseInt(mgr));
			vo.setSal(Integer.parseInt(sal));
			vo.setComm(Integer.parseInt(comm));
			vo.setDeptno(Integer.parseInt(deptno));
			
			if(ei.b1.getText().equals("���")){
				dao.empInsert(vo);
			}else if(ei.b1.getText().equals("����")){
				vo.setEmpno(eno);
				dao.empUpdate(vo);
				card.show(getContentPane(), "EP");
			}
			
			
			ei.setVisible(false);
			getEmpData();
			
		}else if(e.getSource()==ed.b1){
			ei.b1.setText("����");
			EmpVO vo=dao.empUpdateData(Integer.parseInt(ed.tf[0].getText()));
			eno=Integer.parseInt(ed.tf[0].getText());
					
			//������Ʈ �׸� ���� ä��
			ei.tf1.setText(vo.getEname());
			ei.tf2.setText(String.valueOf(vo.getSal()));
			ei.tf3.setText(String.valueOf(vo.getComm()));
			ei.box1.setSelectedItem(vo.getJob());
			ei.box2.setSelectedItem(String.valueOf(vo.getMgr()));
			ei.box3.setSelectedItem(String.valueOf(vo.getDeptno()));
			
			ei.setVisible(true);
			
			
		}else if(e.getSource()==ei.b2){ //���-���
			ei.setVisible(false);
			
		}else if(e.getSource()==ed.b2){
			int check=JOptionPane.showConfirmDialog(this, 
					ed.tf[1].getText()+"���� �����ұ��? ",
					"����",JOptionPane.YES_NO_OPTION);
			if(check==JOptionPane.YES_OPTION){
				//DB ����
				dao.empDelete(
				  Integer.parseInt(ed.tf[0].getText()));
				card.show(getContentPane(), "EP");
				getEmpData();
			}
		}
		
	}

}


















