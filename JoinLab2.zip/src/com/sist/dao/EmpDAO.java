package com.sist.dao;
import java.util.*;
import java.sql.*;

public class EmpDAO {
	private Connection conn;	//����
	private PreparedStatement ps;	//SQL����
	private final String URL="jdbc:oracle:thin:@127.0.0.1:1521:ORCL";
	private final String USER="scott";
	private final String PWD="tiger";
	
	//����̹� ���
	public EmpDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Ŭ���� ���
		}catch(Exception ex){
			System.out.println("EmpDAO()"+ex.getMessage());
		}
	}
	
	//����Ŭ ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, USER, PWD);
			
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	
	//����Ŭ �ݱ�
	public void disConnection(){
		try{
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());	
		}
	}
	
	//���
	public List<EmpVO> empAllData(){
		List<EmpVO> list=
				new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT empno,ename,job,mgr,hiredate,sal,comm,emp.deptno,"
					+"dname,loc,grade "
					+"FROM emp,dept,salgrade "
					+"WHERE emp.deptno=dept.deptno "
					+"AND sal BETWEEN losal AND hisal";
			//SQL��������
			ps=conn.prepareStatement(sql);  //oracle.sql
			//����� �ޱ�
			ResultSet rs=ps.executeQuery();	//@oracle
			//List�߰�
			while(rs.next()){
				EmpVO vo=new EmpVO();
				vo.setEmpno(rs.getInt(1));
				vo.setEname(rs.getString(2));
				vo.setJob(rs.getString(3));
				vo.setMgr(rs.getInt(4));
				vo.setHiredate(rs.getDate(5));
				vo.setSal(rs.getInt(6));
				vo.setComm(rs.getInt(7));
				vo.setDeptno(rs.getInt(8));
				vo.getDvo().setDname(rs.getString(9));
				vo.getDvo().setLoc(rs.getString(10));
				vo.getSvo().setGrade(rs.getInt(11));
				list.add(vo);
			}
			rs.close();
			
		}catch(Exception ex){
			System.out.println("empAllData()"+ex.getMessage());	
		}finally{
			disConnection();
		}
		
		return list;
	}
}















