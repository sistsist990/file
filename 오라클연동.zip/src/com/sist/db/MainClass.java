package com.sist.db;

import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class MainClass extends JFrame 
					implements MouseListener,
					ActionListener{
	JLabel la;
	JTable table;
	DefaultTableModel model;
	JLabel la1;
	JComboBox box;
	JTextField tf;
	JButton b1,b2;
	
	public MainClass(){
		la=new JLabel("������", JLabel.CENTER);
		la.setFont(new Font("���� ����", Font.BOLD, 30));
		
		String[] col={"���","�̸�","����","�Ի���","�μ���ȣ"};
		String[][] row=new String[0][5];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		
		
		
		
		getData();
		
		add("North",la);
		add("Center", js);
		
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}
	
	public void getData(){
		EmpDAO dao=new EmpDAO();
		ArrayList<EmpVO> list=dao.empAllData();
		/*
		 *  <table>
		 *  	<tr>
		 *  		<td>vo.getEmpno()</td>
		 *  	</tr>
		 *  
		 *  </table>
		 */
		for(int i=model.getRowCount()-1;i>=0;i--){
			model.removeRow(i);
		}
		for(EmpVO vo:list){
			String[] data={
				String.valueOf(vo.getEmpno()),
				vo.getEname(),
				vo.getJob(),
				vo.getHiredate().toString(),
				String.valueOf(vo.getDeptno())
			};
			model.addRow(data);
		}
		
	}
	
	public static void main(String[] args){
		new MainClass();
	}

	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

















