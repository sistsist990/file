package com.sist.dao;

/*
 * 	JDBC : Java DataBase Connectivity (ojdbc6.jar)
 * ==============================================
 *	���� ��� : Connection
 *	SQL���� ���� : Statement
 *	����� : ResultSet
 *					  Mybatis	
 *	JDBC => DBCP => ORM   ====> JPA
 *	====
 *	XML ==> Annotation	
 * 
 */
import java.util.*;

import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;

import java.sql.*;

public class EmpDAO {
	private Connection conn;	//����
	private PreparedStatement ps;	//SQL����
	private final String URL="jdbc:oracle:thin:@127.0.0.1:1521:ORCL"; //����Ŭ �ּ�
	
	//����̹� ���
	public EmpDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Ŭ���� ���
		}catch(Exception ex){
			System.out.println("EmpDAO()"+ex.getMessage());
		}
	}
	
	//����Ŭ ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
			
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	
	//����Ŭ ���� ����
	public void disConnection(){
		try{
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());	
		}
	}
	
	public ArrayList<EmpVO> empListData(int page){
		ArrayList<EmpVO> list=
				new ArrayList<>();
		
		try{
			getConnection();
			int rowSize=5;
			//1p ==> 1~5    2p ==> 6~10
			int start=(rowSize*page)-(rowSize-1);
			int end=rowSize*page;
			
			String sql="SELECT empno,ename,job,hiredate,deptno,num "
						+"FROM (SELECT empno,ename,job,hiredate,deptno,rownum as num "
						+"FROM (SELECT empno,ename,job,hiredate,deptno "
						+"FROM emp ORDER BY empno DESC))"
						+"WHERE num BETWEEN "+start+" AND "+end;
			/*
			 *  ORDER BY ==> ����
			 *  ����) ORDER BY �÷��� (ASC|DESC),�÷��� (ASC|DESC)
			 *  			group_id	group_step		group_tab
			 *  AAAAA			1			 1				0
			 *    =>BBBBB		1			 2				1
			 *    	=>CCCCC		1			 3				2
			 *  DDDDD  			2			 4				0
			 *  	=>KKKKK		2			 5				1
			 *  			ORDER BY group_id ASC, group_step ASC 
			 */
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				EmpVO vo=new EmpVO();
				vo.setEmpno(rs.getInt(1));
				vo.setEname(rs.getString(2));
				vo.setJob(rs.getString(3));
				vo.setHiredate(rs.getDate(4));
				vo.setDeptno(rs.getInt(5));
				list.add(vo);
			}
			rs.close();
			
			
		}catch(Exception ex){
			System.out.println("empListData()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		
		return list;
	}
	
	public int empTotalPage(){
		int total=0;
		
		try{
			getConnection();
			String sql="SELECT CEIL(COUNT(*)/5) "
					+"FROM emp";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();
			
		}catch(Exception ex){
			System.out.println("empTotalPage()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return total;
	}
	
	//�󼼺��� ==> ���� �̿��ϱ�
	/*
	 * 	Database(�����������)
	 * 		�޸�:�迭,����,Ŭ����
	 * 		����
	 * 		RDBMS
	 * 
	 *  JOIN
	 *  	=INNER JOIN
	 *  		=EQUI (=)
	 *  			1)Oracle Join
	 *  				SELECT A.a,B.b
	 *  				FROM A,B
	 *  				WHERE A.c=B.c;
	 *  			2)Ansi Join
	 *  				SELECT A.a,B.b
	 *  				FROM A JOIN B
	 *  				ON A.c=B.c;
	 *  			3)Natural Join
	 *  				SELECT a,b
	 *  				FROM A NATURAL JOIN B
	 *  			4)Join ~Using
	 *  				SELECT a,b
	 *  				FROM A JOIN B USING(c)
	 *  		=Non EQUI (=�̿� ������)
	 *  			1)Oracle Join
	 *  				SELECT A.a,B.b
	 *  				FROM A,B	 
	 *  				WHERE A.c>=B.c 
	 *  			2)Ansi Join(��� �����ͺ��̽� ǥ��ȭ)
	 *  				SELECT A.a,B.b
	 *  				FROM A JOIN B	 
	 *  				ON A.c>=B.c 							  
	 *  
	 *  	=Outer Join
	 *  		LEFT OUTER JOIN
	 *  			1)Oracle Join
	 *  				SELECT A.a,B.b
	 *  				FROM A,B
	 *  				WHERE A.c=B.c(+); 
	 *  					<--���δ�� ���̺��� �����Ͱ� ���� ���̺� �������ǿ� (+)�� ����.				
	 *  			2)Ansi Join
	 *  				SELECT A.a,B.b
	 *  				FROM A LEFT OUTER JOIN B
	 *  				ON A.c=B.c;
	 *  		RIGHT OUTER JOIN
	 *  			1)Oracle Join
	 *  				SELECT A.a,B.b
	 *  				FROM A,B	 
	 *  				WHERE A.c(+)=B.c;
	 *  			2)Ansi Join  
	 *  				SELECT A.a,B.b
	 *  				FROM A RIGHT OUTER JOIN B
	 *  				ON A.c=B.c;
	 *  		FULL OUTER JOIN
	 *  			2)Ansi join
	 *  				SELECT A.a,B.b
	 *  				FROM A FULL OUTER JOIN B
	 *  				ON A.c=B.c;
	 */
	public EmpVO empDetailData(int empno){
		EmpVO vo=new EmpVO();
		
		try{
			getConnection();
			String sql="SELECT empno,ename,job,mgr,"
					+"hiredate,sal,comm,dname,loc,"
					+"grade "
					+"FROM emp,dept,salgrade "
					+"WHERE emp.deptno=dept.deptno "
					+"AND sal BETWEEN losal AND hisal "
					+"AND empno=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, empno);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			//���
			vo.setEmpno(rs.getInt(1));
			vo.setEname(rs.getString(2));
			vo.setJob(rs.getString(3));
			vo.setMgr(rs.getInt(4));
			vo.setHiredate(rs.getDate(5));
			vo.setSal(rs.getInt(6));
			vo.setComm(rs.getInt(7));
			vo.getDvo().setDname(rs.getString(8));
			vo.getDvo().setLoc(rs.getString(9));
			vo.getSvo().setGrade(rs.getInt(10));
			rs.close();
			
		}catch(Exception ex){
			System.out.println("empDetailData()"+ex.getMessage());			
		}finally{
			disConnection();
		}
		return vo;
	}
	
	public ArrayList<String> empGetJob(){
		ArrayList<String> list=
			new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT DISTINCT job FROM emp";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				list.add(rs.getString(1));
			}
			rs.close();
			
			
		}catch(Exception ex){
			System.out.println("empGetJob()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return list;
	}
	
	
	public ArrayList<Integer> empGetMgr(){
		ArrayList<Integer> list=
				new ArrayList<>();
		
		try{
			getConnection();
			//
			
			
		}catch(Exception ex){
			System.out.println("empGetMgr()"+ex.getMessage());			
		}finally{
			disConnection();
		}
		
		
		return list;
	}
	
	//��� ==> INSERT
	//void empInsert(EmpVO vo)
}



























