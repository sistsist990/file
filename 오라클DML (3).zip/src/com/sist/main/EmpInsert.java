package com.sist.main;

import javax.swing.JFrame;
import javax.swing.*;
import java.util.*;
import com.sist.dao.*;

public class EmpInsert extends JFrame{
	JLabel la1,la2,la3,la4,la5,la6;
	JTextField tf1,tf2,tf3;
	JComboBox box1,box2,box3;
	JButton b1,b2;
	EmpDAO dao=new EmpDAO();
	
	public EmpInsert(){
		la1=new JLabel("�̸�");
		la2=new JLabel("����");
		la3=new JLabel("���");
		la4=new JLabel("�޿�");
		la5=new JLabel("������");
		la6=new JLabel("�μ�");
		
		tf1=new JTextField();
		tf2=new JTextField();
		tf3=new JTextField();
		
		box1=new JComboBox();
		box2=new JComboBox();
		
		ArrayList<String> job=dao.empGetJob();
		for(String s:job){
			box1.addItem(s);
		}
		
		//box2;
		box3=new JComboBox();
		box3.addItem(10);
		box3.addItem(20);
		box3.addItem(30);
		box3.addItem(40);
		
		b1=new JButton("���");
		b2=new JButton("���");
		
		//��ġ
		setLayout(null);
		
		la1.setBounds(10, 15, 50, 30);
		tf1.setBounds(65, 15, 120, 30);
		
		la2.setBounds(10, 50, 50, 30);
		box1.setBounds(65, 50, 120, 30);
		
		la3.setBounds(10, 85, 50, 30);
		box3.setBounds(65, 85, 120, 30);
		
		la4.setBounds(10, 120, 50, 30);
		tf2.setBounds(65, 120, 120, 30);
		
		la5.setBounds(10, 155, 50, 30);
		tf3.setBounds(65, 155, 120, 30);
		
		la6.setBounds(10, 190, 50, 30);
		box3.setBounds(65, 190, 120, 30);
		
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		p.setBounds(10, 255, 175, 35);
		
		add(la1);add(tf1);
		add(la2);add(box1);
		add(la3);add(box2);
		add(la4);add(tf2);
		add(la5);add(tf3);
		add(la6);add(box3);
		add(p);
		
		setSize(215, 300);
/*		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);*/
		
	}
	
/*	public static void main(String[] args){
		new EmpInsert();
	}*/
}














