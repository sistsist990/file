package com.sist.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;
import java.sql.*;


public class EmpDAO {
	private Connection conn;	//����
	private PreparedStatement ps;	//SQL����
	private final String URL="jdbc:oracle:thin:@127.0.0.1:1521:ORCL"; //����Ŭ �ּ�
	private static EmpDAO dao;
	
	//����̹� ���
	private EmpDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Ŭ���� ���
		}catch(Exception ex){
			System.out.println("EmpDAO()"+ex.getMessage());
		}
	}
	
	//��Ŭ�� ���
	public static EmpDAO newInstance(){
		if(dao==null)
			dao=new EmpDAO();
		return dao;
	}
	
	//����Ŭ ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
			
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	
	//����Ŭ ���� ����
	public void disConnection(){
		try{
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());	
		}
	}
	
	public ArrayList<EmpVO> empAllData(){
		ArrayList<EmpVO> list=
				new ArrayList<>();
		try{
			getConnection();
			String sql="SELECT empno,ename,job,hiredate "
					+"FROM emp";
			
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				EmpVO vo=new EmpVO();
				vo.setEmpno(rs.getInt(1));
				vo.setEname(rs.getString(2));
				vo.setJob(rs.getString(3));
				vo.setHiredate(rs.getDate(4));
				list.add(vo);
			}
			rs.close();
			
		}catch(Exception ex){
			System.out.println("empAllData()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return list;
	}
	
	public EmpVO empDetailData(int empno){
		EmpVO vo=new EmpVO();
		
		return vo;
	}
}










