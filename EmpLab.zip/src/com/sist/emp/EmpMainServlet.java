package com.sist.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sist.dao.EmpDAO;
import com.sist.dao.EmpVO;

public class EmpMainServlet extends HttpServlet{
@Override
public void init(ServletConfig config) throws ServletException {

}

@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=EUC-KR");
		EmpDAO dao=EmpDAO.newInstance();
		ArrayList<EmpVO> list=dao.empAllData();
		PrintWriter out=response.getWriter();
		out.write("<html>");
		out.write("<body>");
		out.write("<center>");
		out.write("<h3>��� ���</h3>");
		out.write("</center>");
		out.write("</body>");
		out.write("</html>");
		
		
		
		
	}
}















