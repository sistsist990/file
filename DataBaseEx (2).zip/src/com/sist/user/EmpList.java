package com.sist.user;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class EmpList extends JPanel{
	JLabel la;
	JComboBox box;
	JButton b1,b2;
	JTable table;
	DefaultTableModel model;
	JTextField tf;
	
	public EmpList(){
		la=new JLabel("Search");
		box=new JComboBox();
		box.addItem("�̸�");
		box.addItem("�Ի���");
		box.addItem("����");
		b1=new JButton("ã��");
		b2=new JButton("���");
		tf=new JTextField(10);
		
		String[] col={"���","�̸�","����","�Ի���","�μ�"};
		String[][] row=new String[0][5];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		JPanel p=new JPanel();
		p.add(la);
		p.add(box);
		p.add(tf);
		p.add(b1);
		p.add(b2);
		
		add("Center",js);
		add("South",p);
	}
	
}















