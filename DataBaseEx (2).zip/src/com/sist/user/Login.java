package com.sist.user;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Login extends JPanel{
	JLabel la1,la2;
	JTextField tf1,tf2;
	JButton b1,b2;
	
	public Login(){
		la1=new JLabel("���");
		la2=new JLabel("�̸�");
		tf1=new JTextField();
		tf2=new JTextField();
		b1=new JButton("�α���");
		b2=new JButton("���");
		
		setLayout(null);
		la1.setBounds(10, 15, 40, 30);
		tf1.setBounds(55, 15, 150, 30);
		
		la2.setBounds(10, 50, 40, 30);
		tf2.setBounds(55, 50, 150, 30);	
		
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		
		p.setBounds(10, 85, 195, 35);
		
		add(la1);add(tf1);
		add(la2);add(tf2);
		add(p);
	}
}
























