package com.sist.user;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.sist.dao.*;

public class EmpMain extends JFrame
			implements ActionListener,MouseListener{

	CardLayout card=new CardLayout();
	Login login=new Login();
	EmpList eList=new EmpList();
	EmpDAO dao=new EmpDAO();
	
	public EmpMain(){
		setLayout(card);
		add("LOG",login);
		add("LIST",eList);
		setSize(640, 550);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		login.b1.addActionListener(this);
		eList.table.addMouseListener(this);
		eList.b1.addActionListener(this);
		eList.b2.addActionListener(this);
		
	}
	
	
	
	
	public static void main(String[] args){
		new EmpMain();
	}
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==login.b1){
			String empno=login.tf1.getText();
			if(empno.length()<1){
				JOptionPane.showMessageDialog(this, "����� �Է��ϼ���.");
				login.tf1.requestFocus();
				return;
			}
			String ename=login.tf2.getText();
			if(ename.length()<1){
				JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���.");
				login.tf2.requestFocus();
				return;
			}
			
			String result=dao.isLogin(Integer.parseInt(empno), ename);
			if(result.equals("NOSABUN")){
				JOptionPane.showMessageDialog(this, "����� �������� �ʽ��ϴ�.");
				login.tf1.setText("");
				login.tf2.setText("");
				login.tf1.requestFocus();
			}else if(result.equals("NONAME")){
				JOptionPane.showMessageDialog(this, "�̸��� Ʋ���ϴ�.");
				login.tf2.setText("");
				login.tf2.requestFocus();
			}else{
				JOptionPane.showMessageDialog(this, ename+"���� �α��� �Ǿ����ϴ�.");
				card.show(getContentPane(), "LIST");
				
			}
			
		}
		
		
	}

}
















