package com.sist.main;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import com.sist.dao.EmpDAO;
import com.sist.dao.EmpVO;

public class EmpMainForm extends JFrame
				implements ActionListener,MouseListener{

	EmpDAO dao=new EmpDAO();
	EmpListPane ep=new EmpListPane();
	EmpDetailPanel ed=new EmpDetailPanel();
	
	CardLayout card=new CardLayout();
	
	int curpage=1;
	int totalPage=0;
	JMenuItem regItem,exitItem;
	
	public EmpMainForm() {
		JMenuBar bar=new JMenuBar();
		JMenu menu=new JMenu("����");
		regItem=new JMenuItem("���");
		exitItem=new JMenuItem("����");
		
		menu.add(regItem);
		menu.add(exitItem);
		
		bar.add(menu);
		setJMenuBar(bar);
		
		setLayout(card);
		
		add("EP",ep);
		
		
		setSize(800,600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	
		getEmpData();
		
		ep.tf.addActionListener(this);
		ep.b1.addActionListener(this);//ã��
		ep.b2.addActionListener(this);//���
		ep.b3.addActionListener(this);//����
		ep.b4.addActionListener(this);//����
		regItem.addActionListener(this); //���
		exitItem.addActionListener(this);//����
		ep.table.addMouseListener(this); //������ ���γ���
		
		
	}
	
	public static void main(String[] args){
		new EmpMainForm();
	}
	
	public void getEmpData(){
		ArrayList<EmpVO> list=
				dao.empListData(curpage);
		for(int i=ep.model.getRowCount()-1;i>=0;i--){
			ep.model.removeRow(i);
		}
		
		for(EmpVO vo:list){
			String[] data={
				String.valueOf(vo.getEmpno()),
				vo.getEname(),
				vo.getJob(),
				vo.getHiredate().toString(),
				String.valueOf(vo.getDeptno())
				
			};
			ep.model.addRow(data);
		}
		totalPage=dao.empTotalPage();
		ep.la2.setText(curpage+" page /"+totalPage+" pages");
		
	}
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==ep.b3){
			if(curpage>1){
				curpage--;
				getEmpData();
			}
		}else if(e.getSource()==ep.b4){
			if(curpage<totalPage){
				curpage++;
				getEmpData();
			}
		}
		
	}

}


















