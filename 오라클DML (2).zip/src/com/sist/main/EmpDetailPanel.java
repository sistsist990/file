package com.sist.main;

import javax.swing.JPanel;

public class EmpDetailPanel extends JPanel{

}
