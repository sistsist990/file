package com.sist.dao;

/*
 * 	JDBC : Java DataBase Connectivity (ojdbc6.jar)
 * ==============================================
 *	���� ��� : Connection
 *	SQL���� ���� : Statement
 *	����� : ResultSet
 *					  Mybatis	
 *	JDBC => DBCP => ORM   ====> JPA
 *	====
 *	XML ==> Annotation	
 * 
 */
import java.util.*;
import java.sql.*;

public class EmpDAO {
	private Connection conn;	//����
	private PreparedStatement ps;	//SQL����
	private final String URL="jdbc:oracle:thin:@127.0.0.1:1521:ORCL"; //����Ŭ �ּ�
	
	//����̹� ���
	public EmpDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); //Ŭ���� ���
		}catch(Exception ex){
			System.out.println("EmpDAO()"+ex.getMessage());
		}
	}
	
	//����Ŭ ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
			
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	
	//����Ŭ ���� ����
	public void disConnection(){
		try{
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());	
		}
	}
	
	public ArrayList<EmpVO> empListData(int page){
		ArrayList<EmpVO> list=
				new ArrayList<>();
		
		try{
			getConnection();
			int rowSize=5;
			//1p ==> 1~5    2p ==> 6~10
			int start=(rowSize*page)-(rowSize-1);
			int end=rowSize*page;
			
			String sql="SELECT empno,ename,job,hiredate,deptno,num "
						+"FROM (SELECT empno,ename,job,hiredate,deptno,rownum as num "
						+"FROM (SELECT empno,ename,job,hiredate,deptno "
						+"FROM emp ORDER BY empno DESC))"
						+"WHERE num BETWEEN "+start+" AND "+end;
			/*
			 *  ORDER BY ==> ����
			 *  ����) ORDER BY �÷��� (ASC|DESC),�÷��� (ASC|DESC)
			 *  			group_id	group_step		group_tab
			 *  AAAAA			1			 1				0
			 *    =>BBBBB		1			 2				1
			 *    	=>CCCCC		1			 3				2
			 *  DDDDD  			2			 4				0
			 *  	=>KKKKK		2			 5				1
			 *  			ORDER BY group_id ASC, group_step ASC 
			 */
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				EmpVO vo=new EmpVO();
				vo.setEmpno(rs.getInt(1));
				vo.setEname(rs.getString(2));
				vo.setJob(rs.getString(3));
				vo.setHiredate(rs.getDate(4));
				vo.setDeptno(rs.getInt(5));
				list.add(vo);
			}
			rs.close();
			
			
		}catch(Exception ex){
			System.out.println("empListData()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		
		return list;
	}
	
	public int empTotalPage(){
		int total=0;
		
		try{
			getConnection();
			String sql="SELECT CEIL(COUNT(*)/5) "
					+"FROM emp";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();
			
		}catch(Exception ex){
			System.out.println("empTotalPage()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return total;
	}
	
	//�󼼺��� ==> ���� �̿��ϱ�
	public EmpVO empDetailData(int empno){
		EmpVO vo=new EmpVO();
		
		try{
			getConnection();
			
			
			
			
		}catch(Exception ex){
			System.out.println("empDetailData()"+ex.getMessage());			
		}finally{
			disConnection();
		}
		
		
		return vo;
	}
	
}



























