package com.sist.post;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.table.*;
import com.sist.dao.*;

public class PostFind extends JFrame
				implements ActionListener{
	JLabel la;
	JButton b;
	JTextField tf;
	JTable table;
	DefaultTableModel model;
	
	public PostFind(){
		la=new JLabel("�� �Է�:");
		tf=new JTextField(10);
		b=new JButton("�˻�");
		
		String[] col={"������ȣ","�ּ�"};
		String[][] row=new String[0][2];
		model=new DefaultTableModel(row, col);
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		JPanel p=new JPanel();
		p.add(la);
		p.add(tf);
		p.add(b);
		
		add("North",p);
		add("Center",js);
		
		setSize(450, 400);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		b.addActionListener(this);
		tf.addActionListener(this);
		
	}
	
	public static void main(String[] args){
		new PostFind();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b || e.getSource()==tf){
			getData();
		}
		
	}
	
	public void getData(){
		try{
			String dong=tf.getText();
			if(dong.length()<1){
				JOptionPane.showMessageDialog(this, "��/��/�� �Է��ϼ���.");
				return;
			}
			
			ZipCodeDAO dao=new ZipCodeDAO();
			int count=dao.zipcodeCount(dong);
			if(count==0){
				JOptionPane.showMessageDialog(this, "�˻��� ������ �����ϴ�.");
				return;				
			}
			
			List<ZipCodeVO> list
				=dao.zipcodeFindData(dong);
			
			for(int i=model.getRowCount()-1;i>=0;i--){
				model.removeRow(i);
			}
			
			for(ZipCodeVO vo:list){
				String[] data={
						vo.getZipCode(),
						vo.getSido()+" "+vo.getGugun()
						+" "+vo.getDong()
						+" "+vo.getBungi()			
				};
				model.addRow(data);
			}
			
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}

}






























