package com.sist.dao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

/*
 * VO,DTO 
 * DAO     ==> DAO+DAO (Service)
 * Manager
 * 
 */

public class ZipCodeDAO {
	private Connection conn; //����Ŭ ���� =>Socket
	private PreparedStatement ps; //SQL���� ���� =>BufferedReader,OutputStream
	private final String URL="jdbc:oracle:thin:@127.0.0.1:1521:ORCL";
	private final String USERNAME="scott";
	private final String PASSWORD="tiger";
	
	//���� ����̴��� ��ġ
	public ZipCodeDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//����
	public void disConnection(){
		try{
			if(ps!=null)ps.close();   //in.close(), out.close()
			if(conn!=null)conn.close(); //socket.close()
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//���
	public int zipcodeCount(String dong){
		int count=0;
		
		try{
			getConnection();
			String sql="SELECT COUNT(*) "
					  +"FROM post "
					  +"WHERE dong LIKE '%'||?||'%'";
			ps=conn.prepareStatement(sql);
			ps.setString(1, dong);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			count=rs.getInt(1);
			rs.close();					
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return count;
	}
	
	public List<ZipCodeVO> zipcodeFindData(String dong){
		List<ZipCodeVO> list=
				new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT zipcode,sido,gugun,dong,NVL(bungi,' ') "
					+"FROM post "
					+"WHERE dong LIKE '%'||?||'%'";
			ps=conn.prepareStatement(sql);
			ps.setString(1, dong);
			
			ResultSet rs=ps.executeQuery();
			//��û�� �����͸� Ŭ���̾�Ʈ�� ����
			while(rs.next()){
				ZipCodeVO vo=new ZipCodeVO();
				vo.setZipCode(rs.getString(1));
				vo.setSido(rs.getString(2));
				vo.setGugun(rs.getString(3));
				vo.setDong(rs.getString(4));
				vo.setBungi(rs.getString(5));
				list.add(vo);
			}
			rs.close();
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return list;
	}
	
}















